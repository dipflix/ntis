// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'neuron.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Neuron _$NeuronFromJson(Map<String, dynamic> json) => Neuron(
      activationAlgorithm: $enumDecode(
          _$ActivationAlgorithmEnumMap, json['activationAlgorithm']),
      parentLayerSize: json['parentLayerSize'] as int,
      learningRate: (json['learningRate'] as num).toDouble(),
      weights: (json['weights'] as List<dynamic>?)
              ?.map((e) => (e as num).toDouble())
              .toList() ??
          const [],
    )
      ..inputs = (json['inputs'] as List<dynamic>)
          .map((e) => (e as num).toDouble())
          .toList()
      ..isInput = json['isInput'] as bool;

Map<String, dynamic> _$NeuronToJson(Neuron instance) => <String, dynamic>{
      'activationAlgorithm':
          _$ActivationAlgorithmEnumMap[instance.activationAlgorithm]!,
      'parentLayerSize': instance.parentLayerSize,
      'learningRate': instance.learningRate,
      'weights': instance.weights,
      'inputs': instance.inputs,
      'isInput': instance.isInput,
    };

const _$ActivationAlgorithmEnumMap = {
  ActivationAlgorithm.sigmoid: 'sigmoid',
  ActivationAlgorithm.relu: 'relu',
  ActivationAlgorithm.lrelu: 'lrelu',
  ActivationAlgorithm.elu: 'elu',
  ActivationAlgorithm.selu: 'selu',
  ActivationAlgorithm.tanh: 'tanh',
  ActivationAlgorithm.softplus: 'softplus',
  ActivationAlgorithm.softsign: 'softsign',
  ActivationAlgorithm.swish: 'swish',
  ActivationAlgorithm.gaussian: 'gaussian',
};
