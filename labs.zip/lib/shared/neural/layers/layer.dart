import 'dart:convert';
import 'dart:io';

import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:labs/shared/neural/neural.dart';

part 'layer.g.dart';

@JsonSerializable(
  createToJson: true,
)
class Layer {
  final ActivationAlgorithm activation;

  final List<Neuron> neurons = [];
  final int size;
  bool isInput = false;

  Layer({
    required this.size,
    required this.activation,
  }) {
    if (size < 1) {
      throw NeuronException('A layer must contain at least one neuron.');
    }
  }

  void initialise({
    required int parentLayerSize,
    required double learningRate,
  }) {
    isInput = parentLayerSize == 0;

    neurons.addAll(
      Iterable.generate(
        size,
        (_) => Neuron(
          activationAlgorithm: activation,
          parentLayerSize: parentLayerSize,
          learningRate: learningRate,
        ),
      ),
    );
  }

  void accept(List<double> inputs) {
    if (isInput) {
      for (var index = 0; index < neurons.length; index++) {
        neurons[index].accept(input: inputs[index]);
      }
      return;
    }

    for (final neuron in neurons) {
      neuron.accept(inputs: inputs);
    }
  }

  List<double> propagate(List<double> weightMargins) {
    final newWeightMargins = <List<double>>[];

    for (final neuron in neurons) {
      newWeightMargins
          .add(neuron.adjust(weightMargin: weightMargins.removeAt(0)));
    }

    return newWeightMargins.reduce(add);
  }

  List<double> get output =>
      List<double>.from(neurons.map<double>((neuron) => neuron.output));

  factory Layer.fromJson(Map<String, dynamic> json) => _$LayerFromJson(json);

  Map<String, dynamic> toJson() =>
      {..._$LayerToJson(this), 'neurons': [...neurons.map((e) => e.toJson())]};

// String toJson() => json.encode({
//       ..._$LayerToJson(this),
//       'neurons': [...neurons.map((e) => e.toJson())],
//     });
}
