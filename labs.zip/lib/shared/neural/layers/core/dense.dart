import 'package:labs/shared/neural/neural.dart';

class Dense extends Layer {
  Dense({
    required super.size,
    required super.activation,
  });
}
