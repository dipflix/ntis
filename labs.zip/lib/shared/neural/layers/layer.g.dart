// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'layer.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Layer _$LayerFromJson(Map<String, dynamic> json) => Layer(
      size: json['size'] as int,
      activation: $enumDecode(_$ActivationAlgorithmEnumMap, json['activation']),
    )..isInput = json['isInput'] as bool;

const _$LayerFieldMap = <String, String>{
  'activation': 'activation',
  'size': 'size',
  'isInput': 'isInput',
};

Map<String, dynamic> _$LayerToJson(Layer instance) => <String, dynamic>{
      'activation': _$ActivationAlgorithmEnumMap[instance.activation]!,
      'size': instance.size,
      'isInput': instance.isInput,
    };

const _$ActivationAlgorithmEnumMap = {
  ActivationAlgorithm.sigmoid: 'sigmoid',
  ActivationAlgorithm.relu: 'relu',
  ActivationAlgorithm.lrelu: 'lrelu',
  ActivationAlgorithm.elu: 'elu',
  ActivationAlgorithm.selu: 'selu',
  ActivationAlgorithm.tanh: 'tanh',
  ActivationAlgorithm.softplus: 'softplus',
  ActivationAlgorithm.softsign: 'softsign',
  ActivationAlgorithm.swish: 'swish',
  ActivationAlgorithm.gaussian: 'gaussian',
};
