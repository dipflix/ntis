import 'dart:io';



import 'package:labs/shared/neural/neural.dart';

import '../network.dart';



mixin Backpropagation on Network {
  void propagateBackwards(List<double> input, List<double> expected) {
    final observed = process(input);

    var errors = subtract(expected, observed);

    for (var index = layers.length - 1; index > 0; index--) {
      errors = layers[index].propagate(errors);
    }
  }

  void train({
    required List<List<double>> inputs,
    required List<List<double>> expected,
    required int iterations,
    bool quiet = false,
  }) {
    if (inputs.isEmpty || expected.isEmpty) {
      log.severe('Both inputs and expected results must not be empty.');
      exit(0);
    }

    if (inputs.length != expected.length) {
      log.severe(
        'Inputs and expected result lists must be of the same length.',
      );
      return;
    }

    if (iterations < 1) {
      log.severe(
        'You cannot train a network without granting it at least one '
        'iteration.',
      );
      return;
    }

    if (quiet) {
      for (var iteration = 0; iteration < iterations; iteration++) {
        for (var index = 0; index < inputs.length; index++) {
          propagateBackwards(inputs[index], expected[index]);
        }
      }
      return;
    }

    for (var iteration = 0; iteration < iterations; iteration++) {
      stopwatch.start();

      for (var index = 0; index < inputs.length; index++) {
        propagateBackwards(inputs[index], expected[index]);
      }

      stopwatch.stop();

      if (iteration % 500 == 0) {
        log.info(
          'Iterations: $iteration/$iterations ~ ETA: ${secondsToETA((stopwatch.elapsedMicroseconds * (iterations - iteration)) ~/ 1000000)}',
        );
      }

      stopwatch.reset();
    }
  }
}
