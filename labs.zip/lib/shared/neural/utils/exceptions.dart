class NeuronException implements Exception {
  String cause;
  NeuronException(this.cause);
}
