part of 'neural_network_bloc.dart';

@freezed
class NeuralNetworkState with _$NeuralNetworkState {
  const factory NeuralNetworkState.unknown() = NeuralNetworState_Unknown;

  const factory NeuralNetworkState.training() = NeuralNetworState_Training;

  const factory NeuralNetworkState.calculate() = NeuralNetworState_Calculate;

  const factory NeuralNetworkState.ready() = NeuralNetworState_Ready;

  const factory NeuralNetworkState.result({
    required Iterable<String> data,
  }) = NeuralNetworState_Result;
}
