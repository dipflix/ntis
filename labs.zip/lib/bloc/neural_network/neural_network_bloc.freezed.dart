// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'neural_network_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$NeuralNetworkEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() doTrain,
    required TResult Function(List<double> value) doDiscernWord,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? doTrain,
    TResult Function(List<double> value)? doDiscernWord,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? doTrain,
    TResult Function(List<double> value)? doDiscernWord,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(NeuralNetworkEvent_DoTrain value) doTrain,
    required TResult Function(NeuralNetworkEvent_DoDiscernWord value)
        doDiscernWord,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(NeuralNetworkEvent_DoTrain value)? doTrain,
    TResult Function(NeuralNetworkEvent_DoDiscernWord value)? doDiscernWord,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(NeuralNetworkEvent_DoTrain value)? doTrain,
    TResult Function(NeuralNetworkEvent_DoDiscernWord value)? doDiscernWord,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NeuralNetworkEventCopyWith<$Res> {
  factory $NeuralNetworkEventCopyWith(
          NeuralNetworkEvent value, $Res Function(NeuralNetworkEvent) then) =
      _$NeuralNetworkEventCopyWithImpl<$Res>;
}

/// @nodoc
class _$NeuralNetworkEventCopyWithImpl<$Res>
    implements $NeuralNetworkEventCopyWith<$Res> {
  _$NeuralNetworkEventCopyWithImpl(this._value, this._then);

  final NeuralNetworkEvent _value;
  // ignore: unused_field
  final $Res Function(NeuralNetworkEvent) _then;
}

/// @nodoc
abstract class _$$NeuralNetworkEvent_DoTrainCopyWith<$Res> {
  factory _$$NeuralNetworkEvent_DoTrainCopyWith(
          _$NeuralNetworkEvent_DoTrain value,
          $Res Function(_$NeuralNetworkEvent_DoTrain) then) =
      __$$NeuralNetworkEvent_DoTrainCopyWithImpl<$Res>;
}

/// @nodoc
class __$$NeuralNetworkEvent_DoTrainCopyWithImpl<$Res>
    extends _$NeuralNetworkEventCopyWithImpl<$Res>
    implements _$$NeuralNetworkEvent_DoTrainCopyWith<$Res> {
  __$$NeuralNetworkEvent_DoTrainCopyWithImpl(
      _$NeuralNetworkEvent_DoTrain _value,
      $Res Function(_$NeuralNetworkEvent_DoTrain) _then)
      : super(_value, (v) => _then(v as _$NeuralNetworkEvent_DoTrain));

  @override
  _$NeuralNetworkEvent_DoTrain get _value =>
      super._value as _$NeuralNetworkEvent_DoTrain;
}

/// @nodoc

class _$NeuralNetworkEvent_DoTrain implements NeuralNetworkEvent_DoTrain {
  const _$NeuralNetworkEvent_DoTrain();

  @override
  String toString() {
    return 'NeuralNetworkEvent.doTrain()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NeuralNetworkEvent_DoTrain);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() doTrain,
    required TResult Function(List<double> value) doDiscernWord,
  }) {
    return doTrain();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? doTrain,
    TResult Function(List<double> value)? doDiscernWord,
  }) {
    return doTrain?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? doTrain,
    TResult Function(List<double> value)? doDiscernWord,
    required TResult orElse(),
  }) {
    if (doTrain != null) {
      return doTrain();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(NeuralNetworkEvent_DoTrain value) doTrain,
    required TResult Function(NeuralNetworkEvent_DoDiscernWord value)
        doDiscernWord,
  }) {
    return doTrain(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(NeuralNetworkEvent_DoTrain value)? doTrain,
    TResult Function(NeuralNetworkEvent_DoDiscernWord value)? doDiscernWord,
  }) {
    return doTrain?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(NeuralNetworkEvent_DoTrain value)? doTrain,
    TResult Function(NeuralNetworkEvent_DoDiscernWord value)? doDiscernWord,
    required TResult orElse(),
  }) {
    if (doTrain != null) {
      return doTrain(this);
    }
    return orElse();
  }
}

abstract class NeuralNetworkEvent_DoTrain implements NeuralNetworkEvent {
  const factory NeuralNetworkEvent_DoTrain() = _$NeuralNetworkEvent_DoTrain;
}

/// @nodoc
abstract class _$$NeuralNetworkEvent_DoDiscernWordCopyWith<$Res> {
  factory _$$NeuralNetworkEvent_DoDiscernWordCopyWith(
          _$NeuralNetworkEvent_DoDiscernWord value,
          $Res Function(_$NeuralNetworkEvent_DoDiscernWord) then) =
      __$$NeuralNetworkEvent_DoDiscernWordCopyWithImpl<$Res>;
  $Res call({List<double> value});
}

/// @nodoc
class __$$NeuralNetworkEvent_DoDiscernWordCopyWithImpl<$Res>
    extends _$NeuralNetworkEventCopyWithImpl<$Res>
    implements _$$NeuralNetworkEvent_DoDiscernWordCopyWith<$Res> {
  __$$NeuralNetworkEvent_DoDiscernWordCopyWithImpl(
      _$NeuralNetworkEvent_DoDiscernWord _value,
      $Res Function(_$NeuralNetworkEvent_DoDiscernWord) _then)
      : super(_value, (v) => _then(v as _$NeuralNetworkEvent_DoDiscernWord));

  @override
  _$NeuralNetworkEvent_DoDiscernWord get _value =>
      super._value as _$NeuralNetworkEvent_DoDiscernWord;

  @override
  $Res call({
    Object? value = freezed,
  }) {
    return _then(_$NeuralNetworkEvent_DoDiscernWord(
      value == freezed
          ? _value._value
          : value // ignore: cast_nullable_to_non_nullable
              as List<double>,
    ));
  }
}

/// @nodoc

class _$NeuralNetworkEvent_DoDiscernWord
    implements NeuralNetworkEvent_DoDiscernWord {
  const _$NeuralNetworkEvent_DoDiscernWord(final List<double> value)
      : _value = value;

  final List<double> _value;
  @override
  List<double> get value {
    // ignore: implicit_dynamic_type
    return EqualUnmodifiableListView(_value);
  }

  @override
  String toString() {
    return 'NeuralNetworkEvent.doDiscernWord(value: $value)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NeuralNetworkEvent_DoDiscernWord &&
            const DeepCollectionEquality().equals(other._value, _value));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(_value));

  @JsonKey(ignore: true)
  @override
  _$$NeuralNetworkEvent_DoDiscernWordCopyWith<
          _$NeuralNetworkEvent_DoDiscernWord>
      get copyWith => __$$NeuralNetworkEvent_DoDiscernWordCopyWithImpl<
          _$NeuralNetworkEvent_DoDiscernWord>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() doTrain,
    required TResult Function(List<double> value) doDiscernWord,
  }) {
    return doDiscernWord(value);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? doTrain,
    TResult Function(List<double> value)? doDiscernWord,
  }) {
    return doDiscernWord?.call(value);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? doTrain,
    TResult Function(List<double> value)? doDiscernWord,
    required TResult orElse(),
  }) {
    if (doDiscernWord != null) {
      return doDiscernWord(value);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(NeuralNetworkEvent_DoTrain value) doTrain,
    required TResult Function(NeuralNetworkEvent_DoDiscernWord value)
        doDiscernWord,
  }) {
    return doDiscernWord(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(NeuralNetworkEvent_DoTrain value)? doTrain,
    TResult Function(NeuralNetworkEvent_DoDiscernWord value)? doDiscernWord,
  }) {
    return doDiscernWord?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(NeuralNetworkEvent_DoTrain value)? doTrain,
    TResult Function(NeuralNetworkEvent_DoDiscernWord value)? doDiscernWord,
    required TResult orElse(),
  }) {
    if (doDiscernWord != null) {
      return doDiscernWord(this);
    }
    return orElse();
  }
}

abstract class NeuralNetworkEvent_DoDiscernWord implements NeuralNetworkEvent {
  const factory NeuralNetworkEvent_DoDiscernWord(final List<double> value) =
      _$NeuralNetworkEvent_DoDiscernWord;

  List<double> get value;
  @JsonKey(ignore: true)
  _$$NeuralNetworkEvent_DoDiscernWordCopyWith<
          _$NeuralNetworkEvent_DoDiscernWord>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$NeuralNetworkState {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() unknown,
    required TResult Function() training,
    required TResult Function() calculate,
    required TResult Function() ready,
    required TResult Function(Iterable<String> data) result,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? unknown,
    TResult Function()? training,
    TResult Function()? calculate,
    TResult Function()? ready,
    TResult Function(Iterable<String> data)? result,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? unknown,
    TResult Function()? training,
    TResult Function()? calculate,
    TResult Function()? ready,
    TResult Function(Iterable<String> data)? result,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(NeuralNetworState_Unknown value) unknown,
    required TResult Function(NeuralNetworState_Training value) training,
    required TResult Function(NeuralNetworState_Calculate value) calculate,
    required TResult Function(NeuralNetworState_Ready value) ready,
    required TResult Function(NeuralNetworState_Result value) result,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(NeuralNetworState_Unknown value)? unknown,
    TResult Function(NeuralNetworState_Training value)? training,
    TResult Function(NeuralNetworState_Calculate value)? calculate,
    TResult Function(NeuralNetworState_Ready value)? ready,
    TResult Function(NeuralNetworState_Result value)? result,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(NeuralNetworState_Unknown value)? unknown,
    TResult Function(NeuralNetworState_Training value)? training,
    TResult Function(NeuralNetworState_Calculate value)? calculate,
    TResult Function(NeuralNetworState_Ready value)? ready,
    TResult Function(NeuralNetworState_Result value)? result,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NeuralNetworkStateCopyWith<$Res> {
  factory $NeuralNetworkStateCopyWith(
          NeuralNetworkState value, $Res Function(NeuralNetworkState) then) =
      _$NeuralNetworkStateCopyWithImpl<$Res>;
}

/// @nodoc
class _$NeuralNetworkStateCopyWithImpl<$Res>
    implements $NeuralNetworkStateCopyWith<$Res> {
  _$NeuralNetworkStateCopyWithImpl(this._value, this._then);

  final NeuralNetworkState _value;
  // ignore: unused_field
  final $Res Function(NeuralNetworkState) _then;
}

/// @nodoc
abstract class _$$NeuralNetworState_UnknownCopyWith<$Res> {
  factory _$$NeuralNetworState_UnknownCopyWith(
          _$NeuralNetworState_Unknown value,
          $Res Function(_$NeuralNetworState_Unknown) then) =
      __$$NeuralNetworState_UnknownCopyWithImpl<$Res>;
}

/// @nodoc
class __$$NeuralNetworState_UnknownCopyWithImpl<$Res>
    extends _$NeuralNetworkStateCopyWithImpl<$Res>
    implements _$$NeuralNetworState_UnknownCopyWith<$Res> {
  __$$NeuralNetworState_UnknownCopyWithImpl(_$NeuralNetworState_Unknown _value,
      $Res Function(_$NeuralNetworState_Unknown) _then)
      : super(_value, (v) => _then(v as _$NeuralNetworState_Unknown));

  @override
  _$NeuralNetworState_Unknown get _value =>
      super._value as _$NeuralNetworState_Unknown;
}

/// @nodoc

class _$NeuralNetworState_Unknown implements NeuralNetworState_Unknown {
  const _$NeuralNetworState_Unknown();

  @override
  String toString() {
    return 'NeuralNetworkState.unknown()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NeuralNetworState_Unknown);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() unknown,
    required TResult Function() training,
    required TResult Function() calculate,
    required TResult Function() ready,
    required TResult Function(Iterable<String> data) result,
  }) {
    return unknown();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? unknown,
    TResult Function()? training,
    TResult Function()? calculate,
    TResult Function()? ready,
    TResult Function(Iterable<String> data)? result,
  }) {
    return unknown?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? unknown,
    TResult Function()? training,
    TResult Function()? calculate,
    TResult Function()? ready,
    TResult Function(Iterable<String> data)? result,
    required TResult orElse(),
  }) {
    if (unknown != null) {
      return unknown();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(NeuralNetworState_Unknown value) unknown,
    required TResult Function(NeuralNetworState_Training value) training,
    required TResult Function(NeuralNetworState_Calculate value) calculate,
    required TResult Function(NeuralNetworState_Ready value) ready,
    required TResult Function(NeuralNetworState_Result value) result,
  }) {
    return unknown(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(NeuralNetworState_Unknown value)? unknown,
    TResult Function(NeuralNetworState_Training value)? training,
    TResult Function(NeuralNetworState_Calculate value)? calculate,
    TResult Function(NeuralNetworState_Ready value)? ready,
    TResult Function(NeuralNetworState_Result value)? result,
  }) {
    return unknown?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(NeuralNetworState_Unknown value)? unknown,
    TResult Function(NeuralNetworState_Training value)? training,
    TResult Function(NeuralNetworState_Calculate value)? calculate,
    TResult Function(NeuralNetworState_Ready value)? ready,
    TResult Function(NeuralNetworState_Result value)? result,
    required TResult orElse(),
  }) {
    if (unknown != null) {
      return unknown(this);
    }
    return orElse();
  }
}

abstract class NeuralNetworState_Unknown implements NeuralNetworkState {
  const factory NeuralNetworState_Unknown() = _$NeuralNetworState_Unknown;
}

/// @nodoc
abstract class _$$NeuralNetworState_TrainingCopyWith<$Res> {
  factory _$$NeuralNetworState_TrainingCopyWith(
          _$NeuralNetworState_Training value,
          $Res Function(_$NeuralNetworState_Training) then) =
      __$$NeuralNetworState_TrainingCopyWithImpl<$Res>;
}

/// @nodoc
class __$$NeuralNetworState_TrainingCopyWithImpl<$Res>
    extends _$NeuralNetworkStateCopyWithImpl<$Res>
    implements _$$NeuralNetworState_TrainingCopyWith<$Res> {
  __$$NeuralNetworState_TrainingCopyWithImpl(
      _$NeuralNetworState_Training _value,
      $Res Function(_$NeuralNetworState_Training) _then)
      : super(_value, (v) => _then(v as _$NeuralNetworState_Training));

  @override
  _$NeuralNetworState_Training get _value =>
      super._value as _$NeuralNetworState_Training;
}

/// @nodoc

class _$NeuralNetworState_Training implements NeuralNetworState_Training {
  const _$NeuralNetworState_Training();

  @override
  String toString() {
    return 'NeuralNetworkState.training()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NeuralNetworState_Training);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() unknown,
    required TResult Function() training,
    required TResult Function() calculate,
    required TResult Function() ready,
    required TResult Function(Iterable<String> data) result,
  }) {
    return training();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? unknown,
    TResult Function()? training,
    TResult Function()? calculate,
    TResult Function()? ready,
    TResult Function(Iterable<String> data)? result,
  }) {
    return training?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? unknown,
    TResult Function()? training,
    TResult Function()? calculate,
    TResult Function()? ready,
    TResult Function(Iterable<String> data)? result,
    required TResult orElse(),
  }) {
    if (training != null) {
      return training();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(NeuralNetworState_Unknown value) unknown,
    required TResult Function(NeuralNetworState_Training value) training,
    required TResult Function(NeuralNetworState_Calculate value) calculate,
    required TResult Function(NeuralNetworState_Ready value) ready,
    required TResult Function(NeuralNetworState_Result value) result,
  }) {
    return training(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(NeuralNetworState_Unknown value)? unknown,
    TResult Function(NeuralNetworState_Training value)? training,
    TResult Function(NeuralNetworState_Calculate value)? calculate,
    TResult Function(NeuralNetworState_Ready value)? ready,
    TResult Function(NeuralNetworState_Result value)? result,
  }) {
    return training?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(NeuralNetworState_Unknown value)? unknown,
    TResult Function(NeuralNetworState_Training value)? training,
    TResult Function(NeuralNetworState_Calculate value)? calculate,
    TResult Function(NeuralNetworState_Ready value)? ready,
    TResult Function(NeuralNetworState_Result value)? result,
    required TResult orElse(),
  }) {
    if (training != null) {
      return training(this);
    }
    return orElse();
  }
}

abstract class NeuralNetworState_Training implements NeuralNetworkState {
  const factory NeuralNetworState_Training() = _$NeuralNetworState_Training;
}

/// @nodoc
abstract class _$$NeuralNetworState_CalculateCopyWith<$Res> {
  factory _$$NeuralNetworState_CalculateCopyWith(
          _$NeuralNetworState_Calculate value,
          $Res Function(_$NeuralNetworState_Calculate) then) =
      __$$NeuralNetworState_CalculateCopyWithImpl<$Res>;
}

/// @nodoc
class __$$NeuralNetworState_CalculateCopyWithImpl<$Res>
    extends _$NeuralNetworkStateCopyWithImpl<$Res>
    implements _$$NeuralNetworState_CalculateCopyWith<$Res> {
  __$$NeuralNetworState_CalculateCopyWithImpl(
      _$NeuralNetworState_Calculate _value,
      $Res Function(_$NeuralNetworState_Calculate) _then)
      : super(_value, (v) => _then(v as _$NeuralNetworState_Calculate));

  @override
  _$NeuralNetworState_Calculate get _value =>
      super._value as _$NeuralNetworState_Calculate;
}

/// @nodoc

class _$NeuralNetworState_Calculate implements NeuralNetworState_Calculate {
  const _$NeuralNetworState_Calculate();

  @override
  String toString() {
    return 'NeuralNetworkState.calculate()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NeuralNetworState_Calculate);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() unknown,
    required TResult Function() training,
    required TResult Function() calculate,
    required TResult Function() ready,
    required TResult Function(Iterable<String> data) result,
  }) {
    return calculate();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? unknown,
    TResult Function()? training,
    TResult Function()? calculate,
    TResult Function()? ready,
    TResult Function(Iterable<String> data)? result,
  }) {
    return calculate?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? unknown,
    TResult Function()? training,
    TResult Function()? calculate,
    TResult Function()? ready,
    TResult Function(Iterable<String> data)? result,
    required TResult orElse(),
  }) {
    if (calculate != null) {
      return calculate();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(NeuralNetworState_Unknown value) unknown,
    required TResult Function(NeuralNetworState_Training value) training,
    required TResult Function(NeuralNetworState_Calculate value) calculate,
    required TResult Function(NeuralNetworState_Ready value) ready,
    required TResult Function(NeuralNetworState_Result value) result,
  }) {
    return calculate(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(NeuralNetworState_Unknown value)? unknown,
    TResult Function(NeuralNetworState_Training value)? training,
    TResult Function(NeuralNetworState_Calculate value)? calculate,
    TResult Function(NeuralNetworState_Ready value)? ready,
    TResult Function(NeuralNetworState_Result value)? result,
  }) {
    return calculate?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(NeuralNetworState_Unknown value)? unknown,
    TResult Function(NeuralNetworState_Training value)? training,
    TResult Function(NeuralNetworState_Calculate value)? calculate,
    TResult Function(NeuralNetworState_Ready value)? ready,
    TResult Function(NeuralNetworState_Result value)? result,
    required TResult orElse(),
  }) {
    if (calculate != null) {
      return calculate(this);
    }
    return orElse();
  }
}

abstract class NeuralNetworState_Calculate implements NeuralNetworkState {
  const factory NeuralNetworState_Calculate() = _$NeuralNetworState_Calculate;
}

/// @nodoc
abstract class _$$NeuralNetworState_ReadyCopyWith<$Res> {
  factory _$$NeuralNetworState_ReadyCopyWith(_$NeuralNetworState_Ready value,
          $Res Function(_$NeuralNetworState_Ready) then) =
      __$$NeuralNetworState_ReadyCopyWithImpl<$Res>;
}

/// @nodoc
class __$$NeuralNetworState_ReadyCopyWithImpl<$Res>
    extends _$NeuralNetworkStateCopyWithImpl<$Res>
    implements _$$NeuralNetworState_ReadyCopyWith<$Res> {
  __$$NeuralNetworState_ReadyCopyWithImpl(_$NeuralNetworState_Ready _value,
      $Res Function(_$NeuralNetworState_Ready) _then)
      : super(_value, (v) => _then(v as _$NeuralNetworState_Ready));

  @override
  _$NeuralNetworState_Ready get _value =>
      super._value as _$NeuralNetworState_Ready;
}

/// @nodoc

class _$NeuralNetworState_Ready implements NeuralNetworState_Ready {
  const _$NeuralNetworState_Ready();

  @override
  String toString() {
    return 'NeuralNetworkState.ready()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NeuralNetworState_Ready);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() unknown,
    required TResult Function() training,
    required TResult Function() calculate,
    required TResult Function() ready,
    required TResult Function(Iterable<String> data) result,
  }) {
    return ready();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? unknown,
    TResult Function()? training,
    TResult Function()? calculate,
    TResult Function()? ready,
    TResult Function(Iterable<String> data)? result,
  }) {
    return ready?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? unknown,
    TResult Function()? training,
    TResult Function()? calculate,
    TResult Function()? ready,
    TResult Function(Iterable<String> data)? result,
    required TResult orElse(),
  }) {
    if (ready != null) {
      return ready();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(NeuralNetworState_Unknown value) unknown,
    required TResult Function(NeuralNetworState_Training value) training,
    required TResult Function(NeuralNetworState_Calculate value) calculate,
    required TResult Function(NeuralNetworState_Ready value) ready,
    required TResult Function(NeuralNetworState_Result value) result,
  }) {
    return ready(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(NeuralNetworState_Unknown value)? unknown,
    TResult Function(NeuralNetworState_Training value)? training,
    TResult Function(NeuralNetworState_Calculate value)? calculate,
    TResult Function(NeuralNetworState_Ready value)? ready,
    TResult Function(NeuralNetworState_Result value)? result,
  }) {
    return ready?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(NeuralNetworState_Unknown value)? unknown,
    TResult Function(NeuralNetworState_Training value)? training,
    TResult Function(NeuralNetworState_Calculate value)? calculate,
    TResult Function(NeuralNetworState_Ready value)? ready,
    TResult Function(NeuralNetworState_Result value)? result,
    required TResult orElse(),
  }) {
    if (ready != null) {
      return ready(this);
    }
    return orElse();
  }
}

abstract class NeuralNetworState_Ready implements NeuralNetworkState {
  const factory NeuralNetworState_Ready() = _$NeuralNetworState_Ready;
}

/// @nodoc
abstract class _$$NeuralNetworState_ResultCopyWith<$Res> {
  factory _$$NeuralNetworState_ResultCopyWith(_$NeuralNetworState_Result value,
          $Res Function(_$NeuralNetworState_Result) then) =
      __$$NeuralNetworState_ResultCopyWithImpl<$Res>;
  $Res call({Iterable<String> data});
}

/// @nodoc
class __$$NeuralNetworState_ResultCopyWithImpl<$Res>
    extends _$NeuralNetworkStateCopyWithImpl<$Res>
    implements _$$NeuralNetworState_ResultCopyWith<$Res> {
  __$$NeuralNetworState_ResultCopyWithImpl(_$NeuralNetworState_Result _value,
      $Res Function(_$NeuralNetworState_Result) _then)
      : super(_value, (v) => _then(v as _$NeuralNetworState_Result));

  @override
  _$NeuralNetworState_Result get _value =>
      super._value as _$NeuralNetworState_Result;

  @override
  $Res call({
    Object? data = freezed,
  }) {
    return _then(_$NeuralNetworState_Result(
      data: data == freezed
          ? _value.data
          : data // ignore: cast_nullable_to_non_nullable
              as Iterable<String>,
    ));
  }
}

/// @nodoc

class _$NeuralNetworState_Result implements NeuralNetworState_Result {
  const _$NeuralNetworState_Result({required this.data});

  @override
  final Iterable<String> data;

  @override
  String toString() {
    return 'NeuralNetworkState.result(data: $data)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$NeuralNetworState_Result &&
            const DeepCollectionEquality().equals(other.data, data));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(data));

  @JsonKey(ignore: true)
  @override
  _$$NeuralNetworState_ResultCopyWith<_$NeuralNetworState_Result>
      get copyWith =>
          __$$NeuralNetworState_ResultCopyWithImpl<_$NeuralNetworState_Result>(
              this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function() unknown,
    required TResult Function() training,
    required TResult Function() calculate,
    required TResult Function() ready,
    required TResult Function(Iterable<String> data) result,
  }) {
    return result(data);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function()? unknown,
    TResult Function()? training,
    TResult Function()? calculate,
    TResult Function()? ready,
    TResult Function(Iterable<String> data)? result,
  }) {
    return result?.call(data);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function()? unknown,
    TResult Function()? training,
    TResult Function()? calculate,
    TResult Function()? ready,
    TResult Function(Iterable<String> data)? result,
    required TResult orElse(),
  }) {
    if (result != null) {
      return result(data);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(NeuralNetworState_Unknown value) unknown,
    required TResult Function(NeuralNetworState_Training value) training,
    required TResult Function(NeuralNetworState_Calculate value) calculate,
    required TResult Function(NeuralNetworState_Ready value) ready,
    required TResult Function(NeuralNetworState_Result value) result,
  }) {
    return result(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(NeuralNetworState_Unknown value)? unknown,
    TResult Function(NeuralNetworState_Training value)? training,
    TResult Function(NeuralNetworState_Calculate value)? calculate,
    TResult Function(NeuralNetworState_Ready value)? ready,
    TResult Function(NeuralNetworState_Result value)? result,
  }) {
    return result?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(NeuralNetworState_Unknown value)? unknown,
    TResult Function(NeuralNetworState_Training value)? training,
    TResult Function(NeuralNetworState_Calculate value)? calculate,
    TResult Function(NeuralNetworState_Ready value)? ready,
    TResult Function(NeuralNetworState_Result value)? result,
    required TResult orElse(),
  }) {
    if (result != null) {
      return result(this);
    }
    return orElse();
  }
}

abstract class NeuralNetworState_Result implements NeuralNetworkState {
  const factory NeuralNetworState_Result(
      {required final Iterable<String> data}) = _$NeuralNetworState_Result;

  Iterable<String> get data;
  @JsonKey(ignore: true)
  _$$NeuralNetworState_ResultCopyWith<_$NeuralNetworState_Result>
      get copyWith => throw _privateConstructorUsedError;
}
