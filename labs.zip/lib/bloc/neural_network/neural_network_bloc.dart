import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:collection/collection.dart';

import 'package:bloc/bloc.dart';
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:labs/shared/file_manager/file_manager.dart';

import 'package:meta/meta.dart';

import 'package:labs/shared/neural/neural.dart';

part 'neural_network_bloc.freezed.dart';

part 'neural_network_event.dart';

part 'neural_network_state.dart';

abstract class NeuralNetworkBloc
    extends Bloc<NeuralNetworkEvent, NeuralNetworkState> {
  NeuralNetworkBloc(super.initialState);
}

class NeuralNetworkBlocImpl extends NeuralNetworkBloc {
  late Sequential network;

  late List<List<double>> trainingData;

  NeuralNetworkBlocImpl()
      : network = Sequential(learningRate: 0.01),
        super(const NeuralNetworkState.unknown()) {
    loadDataFromFile().then((value) => trainingData = value);

    on<NeuralNetworkEvent_DoTrain>(_doTrain);
    on<NeuralNetworkEvent_DoDiscernWord>(_doDiscernWord);
  }

  Future<void> _doTrain(
    NeuralNetworkEvent_DoTrain event,
    Emitter<NeuralNetworkState> emit,
  ) async {
    emit(const NeuralNetworkState.training());

    await Future.delayed(const Duration(milliseconds: 500));
    List<List<double>> expected = generateExpected(trainingData.length);

    network = Sequential(learningRate: 0.01, layers: [
      Layer(
        size: trainingData.first.length,
        activation: ActivationAlgorithm.sigmoid,
      ),
      Layer(
        size: trainingData.length,
        activation: ActivationAlgorithm.sigmoid,
      ),
      Layer(
        size: trainingData.length,
        activation: ActivationAlgorithm.sigmoid,
      ),
    ]);

    network.train(
      inputs: trainingData,
      expected: expected,
      iterations: 100,
      quiet: true,
    );

    await network.saveToJson();

    emit(const NeuralNetworkState.ready());
  }

  List<List<double>> generateExpected(int length) {
    List<List<double>> result = [];

    for (int i = 0; i < length; i++) {
      List<double> temp = [];
      for (int j = 0; j < length; j++) {
        temp.add(0.001);
      }
      temp[i] = 1;
      result.add(temp);
    }

    return result;
  }

  Future<List<List<double>>> loadDataFromFile() async {
    var files = await FileManager.ls();

    List<List<double>> inputs = [];

    for (int i = 0; i < files.length; i++) {
      var element = files[i];
      final matrixString = await FileManager.read(element.path);
      final List<dynamic> listParsed = jsonDecode(matrixString ?? '[]');

      List<double> listData = [];

      for (int j = 0; j < listParsed.length; j++) {
        listData.addAll(List<double>.from(listParsed[j]));
      }
      inputs.add(listData);
    }
    return inputs;
  }

  Future<void> _doDiscernWord(
    NeuralNetworkEvent_DoDiscernWord event,
    Emitter<NeuralNetworkState> emit,
  ) async {
    await network.initFromFile();

    emit(
      NeuralNetworkState.result(
        data: network.process(event.value).map(
              (e) => e.toString(),
            ),
      ),
    );
  }
}
