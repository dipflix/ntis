// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target

part of 'input_matrix_bloc.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
mixin _$InputMatrixEvent {
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int x, int y) onChangeCellStatus,
    required TResult Function() onClear,
    required TResult Function() onSubmit,
    required TResult Function(String dirName, String fileName) onSaveToFile,
    required TResult Function(String fileName) onLoadFile,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function(int x, int y)? onChangeCellStatus,
    TResult Function()? onClear,
    TResult Function()? onSubmit,
    TResult Function(String dirName, String fileName)? onSaveToFile,
    TResult Function(String fileName)? onLoadFile,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int x, int y)? onChangeCellStatus,
    TResult Function()? onClear,
    TResult Function()? onSubmit,
    TResult Function(String dirName, String fileName)? onSaveToFile,
    TResult Function(String fileName)? onLoadFile,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(InputMatrixEvent_OnChangeCellStatus value)
        onChangeCellStatus,
    required TResult Function(InputMatrixEvent_OnClear value) onClear,
    required TResult Function(InputMatrixEvent_OnSubmit value) onSubmit,
    required TResult Function(InputMatrixEvent_OnSaveToFile value) onSaveToFile,
    required TResult Function(InputMatrixEvent_OnLoadFile value) onLoadFile,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(InputMatrixEvent_OnChangeCellStatus value)?
        onChangeCellStatus,
    TResult Function(InputMatrixEvent_OnClear value)? onClear,
    TResult Function(InputMatrixEvent_OnSubmit value)? onSubmit,
    TResult Function(InputMatrixEvent_OnSaveToFile value)? onSaveToFile,
    TResult Function(InputMatrixEvent_OnLoadFile value)? onLoadFile,
  }) =>
      throw _privateConstructorUsedError;
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(InputMatrixEvent_OnChangeCellStatus value)?
        onChangeCellStatus,
    TResult Function(InputMatrixEvent_OnClear value)? onClear,
    TResult Function(InputMatrixEvent_OnSubmit value)? onSubmit,
    TResult Function(InputMatrixEvent_OnSaveToFile value)? onSaveToFile,
    TResult Function(InputMatrixEvent_OnLoadFile value)? onLoadFile,
    required TResult orElse(),
  }) =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $InputMatrixEventCopyWith<$Res> {
  factory $InputMatrixEventCopyWith(
          InputMatrixEvent value, $Res Function(InputMatrixEvent) then) =
      _$InputMatrixEventCopyWithImpl<$Res>;
}

/// @nodoc
class _$InputMatrixEventCopyWithImpl<$Res>
    implements $InputMatrixEventCopyWith<$Res> {
  _$InputMatrixEventCopyWithImpl(this._value, this._then);

  final InputMatrixEvent _value;
  // ignore: unused_field
  final $Res Function(InputMatrixEvent) _then;
}

/// @nodoc
abstract class _$$InputMatrixEvent_OnChangeCellStatusCopyWith<$Res> {
  factory _$$InputMatrixEvent_OnChangeCellStatusCopyWith(
          _$InputMatrixEvent_OnChangeCellStatus value,
          $Res Function(_$InputMatrixEvent_OnChangeCellStatus) then) =
      __$$InputMatrixEvent_OnChangeCellStatusCopyWithImpl<$Res>;
  $Res call({int x, int y});
}

/// @nodoc
class __$$InputMatrixEvent_OnChangeCellStatusCopyWithImpl<$Res>
    extends _$InputMatrixEventCopyWithImpl<$Res>
    implements _$$InputMatrixEvent_OnChangeCellStatusCopyWith<$Res> {
  __$$InputMatrixEvent_OnChangeCellStatusCopyWithImpl(
      _$InputMatrixEvent_OnChangeCellStatus _value,
      $Res Function(_$InputMatrixEvent_OnChangeCellStatus) _then)
      : super(_value, (v) => _then(v as _$InputMatrixEvent_OnChangeCellStatus));

  @override
  _$InputMatrixEvent_OnChangeCellStatus get _value =>
      super._value as _$InputMatrixEvent_OnChangeCellStatus;

  @override
  $Res call({
    Object? x = freezed,
    Object? y = freezed,
  }) {
    return _then(_$InputMatrixEvent_OnChangeCellStatus(
      x == freezed
          ? _value.x
          : x // ignore: cast_nullable_to_non_nullable
              as int,
      y == freezed
          ? _value.y
          : y // ignore: cast_nullable_to_non_nullable
              as int,
    ));
  }
}

/// @nodoc

class _$InputMatrixEvent_OnChangeCellStatus
    implements InputMatrixEvent_OnChangeCellStatus {
  const _$InputMatrixEvent_OnChangeCellStatus(this.x, this.y);

  @override
  final int x;
  @override
  final int y;

  @override
  String toString() {
    return 'InputMatrixEvent.onChangeCellStatus(x: $x, y: $y)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$InputMatrixEvent_OnChangeCellStatus &&
            const DeepCollectionEquality().equals(other.x, x) &&
            const DeepCollectionEquality().equals(other.y, y));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(x),
      const DeepCollectionEquality().hash(y));

  @JsonKey(ignore: true)
  @override
  _$$InputMatrixEvent_OnChangeCellStatusCopyWith<
          _$InputMatrixEvent_OnChangeCellStatus>
      get copyWith => __$$InputMatrixEvent_OnChangeCellStatusCopyWithImpl<
          _$InputMatrixEvent_OnChangeCellStatus>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int x, int y) onChangeCellStatus,
    required TResult Function() onClear,
    required TResult Function() onSubmit,
    required TResult Function(String dirName, String fileName) onSaveToFile,
    required TResult Function(String fileName) onLoadFile,
  }) {
    return onChangeCellStatus(x, y);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function(int x, int y)? onChangeCellStatus,
    TResult Function()? onClear,
    TResult Function()? onSubmit,
    TResult Function(String dirName, String fileName)? onSaveToFile,
    TResult Function(String fileName)? onLoadFile,
  }) {
    return onChangeCellStatus?.call(x, y);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int x, int y)? onChangeCellStatus,
    TResult Function()? onClear,
    TResult Function()? onSubmit,
    TResult Function(String dirName, String fileName)? onSaveToFile,
    TResult Function(String fileName)? onLoadFile,
    required TResult orElse(),
  }) {
    if (onChangeCellStatus != null) {
      return onChangeCellStatus(x, y);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(InputMatrixEvent_OnChangeCellStatus value)
        onChangeCellStatus,
    required TResult Function(InputMatrixEvent_OnClear value) onClear,
    required TResult Function(InputMatrixEvent_OnSubmit value) onSubmit,
    required TResult Function(InputMatrixEvent_OnSaveToFile value) onSaveToFile,
    required TResult Function(InputMatrixEvent_OnLoadFile value) onLoadFile,
  }) {
    return onChangeCellStatus(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(InputMatrixEvent_OnChangeCellStatus value)?
        onChangeCellStatus,
    TResult Function(InputMatrixEvent_OnClear value)? onClear,
    TResult Function(InputMatrixEvent_OnSubmit value)? onSubmit,
    TResult Function(InputMatrixEvent_OnSaveToFile value)? onSaveToFile,
    TResult Function(InputMatrixEvent_OnLoadFile value)? onLoadFile,
  }) {
    return onChangeCellStatus?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(InputMatrixEvent_OnChangeCellStatus value)?
        onChangeCellStatus,
    TResult Function(InputMatrixEvent_OnClear value)? onClear,
    TResult Function(InputMatrixEvent_OnSubmit value)? onSubmit,
    TResult Function(InputMatrixEvent_OnSaveToFile value)? onSaveToFile,
    TResult Function(InputMatrixEvent_OnLoadFile value)? onLoadFile,
    required TResult orElse(),
  }) {
    if (onChangeCellStatus != null) {
      return onChangeCellStatus(this);
    }
    return orElse();
  }
}

abstract class InputMatrixEvent_OnChangeCellStatus implements InputMatrixEvent {
  const factory InputMatrixEvent_OnChangeCellStatus(final int x, final int y) =
      _$InputMatrixEvent_OnChangeCellStatus;

  int get x;
  int get y;
  @JsonKey(ignore: true)
  _$$InputMatrixEvent_OnChangeCellStatusCopyWith<
          _$InputMatrixEvent_OnChangeCellStatus>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$InputMatrixEvent_OnClearCopyWith<$Res> {
  factory _$$InputMatrixEvent_OnClearCopyWith(_$InputMatrixEvent_OnClear value,
          $Res Function(_$InputMatrixEvent_OnClear) then) =
      __$$InputMatrixEvent_OnClearCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InputMatrixEvent_OnClearCopyWithImpl<$Res>
    extends _$InputMatrixEventCopyWithImpl<$Res>
    implements _$$InputMatrixEvent_OnClearCopyWith<$Res> {
  __$$InputMatrixEvent_OnClearCopyWithImpl(_$InputMatrixEvent_OnClear _value,
      $Res Function(_$InputMatrixEvent_OnClear) _then)
      : super(_value, (v) => _then(v as _$InputMatrixEvent_OnClear));

  @override
  _$InputMatrixEvent_OnClear get _value =>
      super._value as _$InputMatrixEvent_OnClear;
}

/// @nodoc

class _$InputMatrixEvent_OnClear implements InputMatrixEvent_OnClear {
  const _$InputMatrixEvent_OnClear();

  @override
  String toString() {
    return 'InputMatrixEvent.onClear()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$InputMatrixEvent_OnClear);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int x, int y) onChangeCellStatus,
    required TResult Function() onClear,
    required TResult Function() onSubmit,
    required TResult Function(String dirName, String fileName) onSaveToFile,
    required TResult Function(String fileName) onLoadFile,
  }) {
    return onClear();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function(int x, int y)? onChangeCellStatus,
    TResult Function()? onClear,
    TResult Function()? onSubmit,
    TResult Function(String dirName, String fileName)? onSaveToFile,
    TResult Function(String fileName)? onLoadFile,
  }) {
    return onClear?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int x, int y)? onChangeCellStatus,
    TResult Function()? onClear,
    TResult Function()? onSubmit,
    TResult Function(String dirName, String fileName)? onSaveToFile,
    TResult Function(String fileName)? onLoadFile,
    required TResult orElse(),
  }) {
    if (onClear != null) {
      return onClear();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(InputMatrixEvent_OnChangeCellStatus value)
        onChangeCellStatus,
    required TResult Function(InputMatrixEvent_OnClear value) onClear,
    required TResult Function(InputMatrixEvent_OnSubmit value) onSubmit,
    required TResult Function(InputMatrixEvent_OnSaveToFile value) onSaveToFile,
    required TResult Function(InputMatrixEvent_OnLoadFile value) onLoadFile,
  }) {
    return onClear(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(InputMatrixEvent_OnChangeCellStatus value)?
        onChangeCellStatus,
    TResult Function(InputMatrixEvent_OnClear value)? onClear,
    TResult Function(InputMatrixEvent_OnSubmit value)? onSubmit,
    TResult Function(InputMatrixEvent_OnSaveToFile value)? onSaveToFile,
    TResult Function(InputMatrixEvent_OnLoadFile value)? onLoadFile,
  }) {
    return onClear?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(InputMatrixEvent_OnChangeCellStatus value)?
        onChangeCellStatus,
    TResult Function(InputMatrixEvent_OnClear value)? onClear,
    TResult Function(InputMatrixEvent_OnSubmit value)? onSubmit,
    TResult Function(InputMatrixEvent_OnSaveToFile value)? onSaveToFile,
    TResult Function(InputMatrixEvent_OnLoadFile value)? onLoadFile,
    required TResult orElse(),
  }) {
    if (onClear != null) {
      return onClear(this);
    }
    return orElse();
  }
}

abstract class InputMatrixEvent_OnClear implements InputMatrixEvent {
  const factory InputMatrixEvent_OnClear() = _$InputMatrixEvent_OnClear;
}

/// @nodoc
abstract class _$$InputMatrixEvent_OnSubmitCopyWith<$Res> {
  factory _$$InputMatrixEvent_OnSubmitCopyWith(
          _$InputMatrixEvent_OnSubmit value,
          $Res Function(_$InputMatrixEvent_OnSubmit) then) =
      __$$InputMatrixEvent_OnSubmitCopyWithImpl<$Res>;
}

/// @nodoc
class __$$InputMatrixEvent_OnSubmitCopyWithImpl<$Res>
    extends _$InputMatrixEventCopyWithImpl<$Res>
    implements _$$InputMatrixEvent_OnSubmitCopyWith<$Res> {
  __$$InputMatrixEvent_OnSubmitCopyWithImpl(_$InputMatrixEvent_OnSubmit _value,
      $Res Function(_$InputMatrixEvent_OnSubmit) _then)
      : super(_value, (v) => _then(v as _$InputMatrixEvent_OnSubmit));

  @override
  _$InputMatrixEvent_OnSubmit get _value =>
      super._value as _$InputMatrixEvent_OnSubmit;
}

/// @nodoc

class _$InputMatrixEvent_OnSubmit implements InputMatrixEvent_OnSubmit {
  const _$InputMatrixEvent_OnSubmit();

  @override
  String toString() {
    return 'InputMatrixEvent.onSubmit()';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$InputMatrixEvent_OnSubmit);
  }

  @override
  int get hashCode => runtimeType.hashCode;

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int x, int y) onChangeCellStatus,
    required TResult Function() onClear,
    required TResult Function() onSubmit,
    required TResult Function(String dirName, String fileName) onSaveToFile,
    required TResult Function(String fileName) onLoadFile,
  }) {
    return onSubmit();
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function(int x, int y)? onChangeCellStatus,
    TResult Function()? onClear,
    TResult Function()? onSubmit,
    TResult Function(String dirName, String fileName)? onSaveToFile,
    TResult Function(String fileName)? onLoadFile,
  }) {
    return onSubmit?.call();
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int x, int y)? onChangeCellStatus,
    TResult Function()? onClear,
    TResult Function()? onSubmit,
    TResult Function(String dirName, String fileName)? onSaveToFile,
    TResult Function(String fileName)? onLoadFile,
    required TResult orElse(),
  }) {
    if (onSubmit != null) {
      return onSubmit();
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(InputMatrixEvent_OnChangeCellStatus value)
        onChangeCellStatus,
    required TResult Function(InputMatrixEvent_OnClear value) onClear,
    required TResult Function(InputMatrixEvent_OnSubmit value) onSubmit,
    required TResult Function(InputMatrixEvent_OnSaveToFile value) onSaveToFile,
    required TResult Function(InputMatrixEvent_OnLoadFile value) onLoadFile,
  }) {
    return onSubmit(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(InputMatrixEvent_OnChangeCellStatus value)?
        onChangeCellStatus,
    TResult Function(InputMatrixEvent_OnClear value)? onClear,
    TResult Function(InputMatrixEvent_OnSubmit value)? onSubmit,
    TResult Function(InputMatrixEvent_OnSaveToFile value)? onSaveToFile,
    TResult Function(InputMatrixEvent_OnLoadFile value)? onLoadFile,
  }) {
    return onSubmit?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(InputMatrixEvent_OnChangeCellStatus value)?
        onChangeCellStatus,
    TResult Function(InputMatrixEvent_OnClear value)? onClear,
    TResult Function(InputMatrixEvent_OnSubmit value)? onSubmit,
    TResult Function(InputMatrixEvent_OnSaveToFile value)? onSaveToFile,
    TResult Function(InputMatrixEvent_OnLoadFile value)? onLoadFile,
    required TResult orElse(),
  }) {
    if (onSubmit != null) {
      return onSubmit(this);
    }
    return orElse();
  }
}

abstract class InputMatrixEvent_OnSubmit implements InputMatrixEvent {
  const factory InputMatrixEvent_OnSubmit() = _$InputMatrixEvent_OnSubmit;
}

/// @nodoc
abstract class _$$InputMatrixEvent_OnSaveToFileCopyWith<$Res> {
  factory _$$InputMatrixEvent_OnSaveToFileCopyWith(
          _$InputMatrixEvent_OnSaveToFile value,
          $Res Function(_$InputMatrixEvent_OnSaveToFile) then) =
      __$$InputMatrixEvent_OnSaveToFileCopyWithImpl<$Res>;
  $Res call({String dirName, String fileName});
}

/// @nodoc
class __$$InputMatrixEvent_OnSaveToFileCopyWithImpl<$Res>
    extends _$InputMatrixEventCopyWithImpl<$Res>
    implements _$$InputMatrixEvent_OnSaveToFileCopyWith<$Res> {
  __$$InputMatrixEvent_OnSaveToFileCopyWithImpl(
      _$InputMatrixEvent_OnSaveToFile _value,
      $Res Function(_$InputMatrixEvent_OnSaveToFile) _then)
      : super(_value, (v) => _then(v as _$InputMatrixEvent_OnSaveToFile));

  @override
  _$InputMatrixEvent_OnSaveToFile get _value =>
      super._value as _$InputMatrixEvent_OnSaveToFile;

  @override
  $Res call({
    Object? dirName = freezed,
    Object? fileName = freezed,
  }) {
    return _then(_$InputMatrixEvent_OnSaveToFile(
      dirName == freezed
          ? _value.dirName
          : dirName // ignore: cast_nullable_to_non_nullable
              as String,
      fileName == freezed
          ? _value.fileName
          : fileName // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$InputMatrixEvent_OnSaveToFile implements InputMatrixEvent_OnSaveToFile {
  const _$InputMatrixEvent_OnSaveToFile(this.dirName, this.fileName);

  @override
  final String dirName;
  @override
  final String fileName;

  @override
  String toString() {
    return 'InputMatrixEvent.onSaveToFile(dirName: $dirName, fileName: $fileName)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$InputMatrixEvent_OnSaveToFile &&
            const DeepCollectionEquality().equals(other.dirName, dirName) &&
            const DeepCollectionEquality().equals(other.fileName, fileName));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(dirName),
      const DeepCollectionEquality().hash(fileName));

  @JsonKey(ignore: true)
  @override
  _$$InputMatrixEvent_OnSaveToFileCopyWith<_$InputMatrixEvent_OnSaveToFile>
      get copyWith => __$$InputMatrixEvent_OnSaveToFileCopyWithImpl<
          _$InputMatrixEvent_OnSaveToFile>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int x, int y) onChangeCellStatus,
    required TResult Function() onClear,
    required TResult Function() onSubmit,
    required TResult Function(String dirName, String fileName) onSaveToFile,
    required TResult Function(String fileName) onLoadFile,
  }) {
    return onSaveToFile(dirName, fileName);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function(int x, int y)? onChangeCellStatus,
    TResult Function()? onClear,
    TResult Function()? onSubmit,
    TResult Function(String dirName, String fileName)? onSaveToFile,
    TResult Function(String fileName)? onLoadFile,
  }) {
    return onSaveToFile?.call(dirName, fileName);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int x, int y)? onChangeCellStatus,
    TResult Function()? onClear,
    TResult Function()? onSubmit,
    TResult Function(String dirName, String fileName)? onSaveToFile,
    TResult Function(String fileName)? onLoadFile,
    required TResult orElse(),
  }) {
    if (onSaveToFile != null) {
      return onSaveToFile(dirName, fileName);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(InputMatrixEvent_OnChangeCellStatus value)
        onChangeCellStatus,
    required TResult Function(InputMatrixEvent_OnClear value) onClear,
    required TResult Function(InputMatrixEvent_OnSubmit value) onSubmit,
    required TResult Function(InputMatrixEvent_OnSaveToFile value) onSaveToFile,
    required TResult Function(InputMatrixEvent_OnLoadFile value) onLoadFile,
  }) {
    return onSaveToFile(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(InputMatrixEvent_OnChangeCellStatus value)?
        onChangeCellStatus,
    TResult Function(InputMatrixEvent_OnClear value)? onClear,
    TResult Function(InputMatrixEvent_OnSubmit value)? onSubmit,
    TResult Function(InputMatrixEvent_OnSaveToFile value)? onSaveToFile,
    TResult Function(InputMatrixEvent_OnLoadFile value)? onLoadFile,
  }) {
    return onSaveToFile?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(InputMatrixEvent_OnChangeCellStatus value)?
        onChangeCellStatus,
    TResult Function(InputMatrixEvent_OnClear value)? onClear,
    TResult Function(InputMatrixEvent_OnSubmit value)? onSubmit,
    TResult Function(InputMatrixEvent_OnSaveToFile value)? onSaveToFile,
    TResult Function(InputMatrixEvent_OnLoadFile value)? onLoadFile,
    required TResult orElse(),
  }) {
    if (onSaveToFile != null) {
      return onSaveToFile(this);
    }
    return orElse();
  }
}

abstract class InputMatrixEvent_OnSaveToFile implements InputMatrixEvent {
  const factory InputMatrixEvent_OnSaveToFile(
          final String dirName, final String fileName) =
      _$InputMatrixEvent_OnSaveToFile;

  String get dirName;
  String get fileName;
  @JsonKey(ignore: true)
  _$$InputMatrixEvent_OnSaveToFileCopyWith<_$InputMatrixEvent_OnSaveToFile>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
abstract class _$$InputMatrixEvent_OnLoadFileCopyWith<$Res> {
  factory _$$InputMatrixEvent_OnLoadFileCopyWith(
          _$InputMatrixEvent_OnLoadFile value,
          $Res Function(_$InputMatrixEvent_OnLoadFile) then) =
      __$$InputMatrixEvent_OnLoadFileCopyWithImpl<$Res>;
  $Res call({String fileName});
}

/// @nodoc
class __$$InputMatrixEvent_OnLoadFileCopyWithImpl<$Res>
    extends _$InputMatrixEventCopyWithImpl<$Res>
    implements _$$InputMatrixEvent_OnLoadFileCopyWith<$Res> {
  __$$InputMatrixEvent_OnLoadFileCopyWithImpl(
      _$InputMatrixEvent_OnLoadFile _value,
      $Res Function(_$InputMatrixEvent_OnLoadFile) _then)
      : super(_value, (v) => _then(v as _$InputMatrixEvent_OnLoadFile));

  @override
  _$InputMatrixEvent_OnLoadFile get _value =>
      super._value as _$InputMatrixEvent_OnLoadFile;

  @override
  $Res call({
    Object? fileName = freezed,
  }) {
    return _then(_$InputMatrixEvent_OnLoadFile(
      fileName == freezed
          ? _value.fileName
          : fileName // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$InputMatrixEvent_OnLoadFile implements InputMatrixEvent_OnLoadFile {
  const _$InputMatrixEvent_OnLoadFile(this.fileName);

  @override
  final String fileName;

  @override
  String toString() {
    return 'InputMatrixEvent.onLoadFile(fileName: $fileName)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$InputMatrixEvent_OnLoadFile &&
            const DeepCollectionEquality().equals(other.fileName, fileName));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, const DeepCollectionEquality().hash(fileName));

  @JsonKey(ignore: true)
  @override
  _$$InputMatrixEvent_OnLoadFileCopyWith<_$InputMatrixEvent_OnLoadFile>
      get copyWith => __$$InputMatrixEvent_OnLoadFileCopyWithImpl<
          _$InputMatrixEvent_OnLoadFile>(this, _$identity);

  @override
  @optionalTypeArgs
  TResult when<TResult extends Object?>({
    required TResult Function(int x, int y) onChangeCellStatus,
    required TResult Function() onClear,
    required TResult Function() onSubmit,
    required TResult Function(String dirName, String fileName) onSaveToFile,
    required TResult Function(String fileName) onLoadFile,
  }) {
    return onLoadFile(fileName);
  }

  @override
  @optionalTypeArgs
  TResult? whenOrNull<TResult extends Object?>({
    TResult Function(int x, int y)? onChangeCellStatus,
    TResult Function()? onClear,
    TResult Function()? onSubmit,
    TResult Function(String dirName, String fileName)? onSaveToFile,
    TResult Function(String fileName)? onLoadFile,
  }) {
    return onLoadFile?.call(fileName);
  }

  @override
  @optionalTypeArgs
  TResult maybeWhen<TResult extends Object?>({
    TResult Function(int x, int y)? onChangeCellStatus,
    TResult Function()? onClear,
    TResult Function()? onSubmit,
    TResult Function(String dirName, String fileName)? onSaveToFile,
    TResult Function(String fileName)? onLoadFile,
    required TResult orElse(),
  }) {
    if (onLoadFile != null) {
      return onLoadFile(fileName);
    }
    return orElse();
  }

  @override
  @optionalTypeArgs
  TResult map<TResult extends Object?>({
    required TResult Function(InputMatrixEvent_OnChangeCellStatus value)
        onChangeCellStatus,
    required TResult Function(InputMatrixEvent_OnClear value) onClear,
    required TResult Function(InputMatrixEvent_OnSubmit value) onSubmit,
    required TResult Function(InputMatrixEvent_OnSaveToFile value) onSaveToFile,
    required TResult Function(InputMatrixEvent_OnLoadFile value) onLoadFile,
  }) {
    return onLoadFile(this);
  }

  @override
  @optionalTypeArgs
  TResult? mapOrNull<TResult extends Object?>({
    TResult Function(InputMatrixEvent_OnChangeCellStatus value)?
        onChangeCellStatus,
    TResult Function(InputMatrixEvent_OnClear value)? onClear,
    TResult Function(InputMatrixEvent_OnSubmit value)? onSubmit,
    TResult Function(InputMatrixEvent_OnSaveToFile value)? onSaveToFile,
    TResult Function(InputMatrixEvent_OnLoadFile value)? onLoadFile,
  }) {
    return onLoadFile?.call(this);
  }

  @override
  @optionalTypeArgs
  TResult maybeMap<TResult extends Object?>({
    TResult Function(InputMatrixEvent_OnChangeCellStatus value)?
        onChangeCellStatus,
    TResult Function(InputMatrixEvent_OnClear value)? onClear,
    TResult Function(InputMatrixEvent_OnSubmit value)? onSubmit,
    TResult Function(InputMatrixEvent_OnSaveToFile value)? onSaveToFile,
    TResult Function(InputMatrixEvent_OnLoadFile value)? onLoadFile,
    required TResult orElse(),
  }) {
    if (onLoadFile != null) {
      return onLoadFile(this);
    }
    return orElse();
  }
}

abstract class InputMatrixEvent_OnLoadFile implements InputMatrixEvent {
  const factory InputMatrixEvent_OnLoadFile(final String fileName) =
      _$InputMatrixEvent_OnLoadFile;

  String get fileName;
  @JsonKey(ignore: true)
  _$$InputMatrixEvent_OnLoadFileCopyWith<_$InputMatrixEvent_OnLoadFile>
      get copyWith => throw _privateConstructorUsedError;
}

/// @nodoc
mixin _$InputMatrixState {
  Iterable<FileSystemEntity> get files => throw _privateConstructorUsedError;
  Matrix get matrix => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $InputMatrixStateCopyWith<InputMatrixState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $InputMatrixStateCopyWith<$Res> {
  factory $InputMatrixStateCopyWith(
          InputMatrixState value, $Res Function(InputMatrixState) then) =
      _$InputMatrixStateCopyWithImpl<$Res>;
  $Res call({Iterable<FileSystemEntity> files, Matrix matrix});
}

/// @nodoc
class _$InputMatrixStateCopyWithImpl<$Res>
    implements $InputMatrixStateCopyWith<$Res> {
  _$InputMatrixStateCopyWithImpl(this._value, this._then);

  final InputMatrixState _value;
  // ignore: unused_field
  final $Res Function(InputMatrixState) _then;

  @override
  $Res call({
    Object? files = freezed,
    Object? matrix = freezed,
  }) {
    return _then(_value.copyWith(
      files: files == freezed
          ? _value.files
          : files // ignore: cast_nullable_to_non_nullable
              as Iterable<FileSystemEntity>,
      matrix: matrix == freezed
          ? _value.matrix
          : matrix // ignore: cast_nullable_to_non_nullable
              as Matrix,
    ));
  }
}

/// @nodoc
abstract class _$$_InputMatrixStateCopyWith<$Res>
    implements $InputMatrixStateCopyWith<$Res> {
  factory _$$_InputMatrixStateCopyWith(
          _$_InputMatrixState value, $Res Function(_$_InputMatrixState) then) =
      __$$_InputMatrixStateCopyWithImpl<$Res>;
  @override
  $Res call({Iterable<FileSystemEntity> files, Matrix matrix});
}

/// @nodoc
class __$$_InputMatrixStateCopyWithImpl<$Res>
    extends _$InputMatrixStateCopyWithImpl<$Res>
    implements _$$_InputMatrixStateCopyWith<$Res> {
  __$$_InputMatrixStateCopyWithImpl(
      _$_InputMatrixState _value, $Res Function(_$_InputMatrixState) _then)
      : super(_value, (v) => _then(v as _$_InputMatrixState));

  @override
  _$_InputMatrixState get _value => super._value as _$_InputMatrixState;

  @override
  $Res call({
    Object? files = freezed,
    Object? matrix = freezed,
  }) {
    return _then(_$_InputMatrixState(
      files: files == freezed
          ? _value.files
          : files // ignore: cast_nullable_to_non_nullable
              as Iterable<FileSystemEntity>,
      matrix: matrix == freezed
          ? _value.matrix
          : matrix // ignore: cast_nullable_to_non_nullable
              as Matrix,
    ));
  }
}

/// @nodoc

class _$_InputMatrixState implements _InputMatrixState {
  const _$_InputMatrixState({required this.files, required this.matrix});

  @override
  final Iterable<FileSystemEntity> files;
  @override
  final Matrix matrix;

  @override
  String toString() {
    return 'InputMatrixState(files: $files, matrix: $matrix)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$_InputMatrixState &&
            const DeepCollectionEquality().equals(other.files, files) &&
            const DeepCollectionEquality().equals(other.matrix, matrix));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType,
      const DeepCollectionEquality().hash(files),
      const DeepCollectionEquality().hash(matrix));

  @JsonKey(ignore: true)
  @override
  _$$_InputMatrixStateCopyWith<_$_InputMatrixState> get copyWith =>
      __$$_InputMatrixStateCopyWithImpl<_$_InputMatrixState>(this, _$identity);
}

abstract class _InputMatrixState implements InputMatrixState {
  const factory _InputMatrixState(
      {required final Iterable<FileSystemEntity> files,
      required final Matrix matrix}) = _$_InputMatrixState;

  @override
  Iterable<FileSystemEntity> get files;
  @override
  Matrix get matrix;
  @override
  @JsonKey(ignore: true)
  _$$_InputMatrixStateCopyWith<_$_InputMatrixState> get copyWith =>
      throw _privateConstructorUsedError;
}
