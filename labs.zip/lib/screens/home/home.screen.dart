import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:labs/bloc/bloc.dart';
import 'package:labs/shared/neural/neural.dart';

import 'package:labs/ui/ui.dart';

class HomeScreen extends StatelessWidget {
  late InputMatrixBloc cubit;
  late NeuralNetworkBloc networkBloc;

  HomeScreen({Key? key}) : super(key: key) {
    cubit = InputMatrixBloc(5, 7);

    networkBloc = NeuralNetworkBlocImpl();
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return MultiBlocProvider(
      providers: [
        BlocProvider.value(value: cubit),
        BlocProvider.value(value: networkBloc),
      ],
      child: Scaffold(
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    buildDrawingMatrixCard(),
                    Gap.vertical.small(),
                    buildActionsCard(),
                    Gap.vertical.small(),
                    // Text(
                    //     "Layers length: ${networkBloc.layers.length.toString()}",
                    //     style: textTheme.headlineSmall),
                    BlocBuilder<NeuralNetworkBloc, NeuralNetworkState>(
                      builder: (context, state) {
                        return state.when(
                          unknown: () => const SizedBox.shrink(),
                          training: () => Column(
                            children: const [
                              Text("Training..."),
                            ],
                          ),
                          calculate: () => const Text("Calculate..."),
                          ready: () {
                            return Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: const [
                                Text("ready..."),
                              ],
                            );
                          },
                          result: (data) {
                            return BlocBuilder<InputMatrixBloc,
                                InputMatrixState>(
                              builder: (context, state) {
                                return generateNeuronsView(state, data);
                              },
                            );
                          },
                        );
                      },
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget generateNeuronsView(InputMatrixState state, Iterable<String> data) {
    return Column(
      children: () {
        List<Widget> items = [];

        for (int i = 0; i < state.files.length; i++) {
          var element = state.files.elementAt(i);
          final file = element.path.split('/')[1];
          final colorPerc = double.parse(data.elementAt(i));
          items.add(
            Container(
              width: 200,
              height: 32,
              decoration: BoxDecoration(
                color: Colors.red.withOpacity(
                  colorPerc > 1 ? 1 : colorPerc,
                ),
              ),
              child: Center(
                  child: Text(
                "$file  ${double.parse(data.elementAt(i)).toStringAsFixed(4)}",
                style: const TextStyle(fontSize: 14),
              )),
            ),
          );
        }

        return items;
      }.call(),
    );
  }

  Card buildDrawingMatrixCard() {
    return const Card(
      child: Padding(
        padding: EdgeInsets.all(24),
        child: MatrixInputsForm(
          width: 5,
          height: 9,
        ),
      ),
    );
  }

  Card buildActionsCard() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            Gap.horizontal.regular(),
            ElevatedButton(
              onPressed: () async {
                networkBloc.add(const NeuralNetworkEvent.doTrain());
              },
              child: const Text('Start training'),
            ),
            Gap.horizontal.regular(),
            ElevatedButton(
              onPressed: () {
                networkBloc.add(
                  NeuralNetworkEvent.doDiscernWord(
                    cubit.state.matrix.toListDouble(),
                  ),
                );
              },
              child: const Text('Discern word'),
            ),
          ],
        ),
      ),
    );
  }
}
